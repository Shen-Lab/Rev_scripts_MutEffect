#! /usr/bin/env bash

#identify 3-node motifs in an undirected PPI network using mfinder1.21

cd mfinder1.21 # mfinder1.21 and data_out have the same parent directory
./mfinder ../data_out/wang_network.txt -s 3 -r 100 -f ../data_out/PC_network -omem  -maxmem 50000000
