#!/usr/bin/env Rscript
# 20170310 by Haoran Chen
# edited by Suping Deng on 11/28/2018

#transfer the original human signaling network to an undirected protein-protein network
# Get PPI network
PPI_sig_network = read.table(file("stdin"),sep = ' ', header = TRUE)


# Exclude self-loops from the list
i = 1
len = length(PPI_sig_network$src_id)
self_loop = data.frame()
while (i <= len){
  if (PPI_sig_network$src_id[i] == PPI_sig_network$dest_id[i]){
    self_loop = rbind(self_loop, PPI_sig_network[i,])
    PPI_sig_network = PPI_sig_network[-i, ]
    len = len - 1
  } else{
    i = i + 1
  }
}

PPI_sig_network = unique(PPI_sig_network)

write.table(PPI_sig_network,"../data_out/PPI_sig_network_no_selfloop.txt",sep="\t",row.names=FALSE,quote=FALSE) 

#network_gene_id=unique(c(PPI_sig_netwok$src_id,PPI_sig_network$dest_id))
#write.table(network_gene_id, "../data_out/network_gene_id.txt", sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE)

# Output pathway topology with double directed path for undirected paths


PPI_sig_network_index_double = sort(unique(c(PPI_sig_network$src_id, PPI_sig_network$dest_id)))

PPI_sig_network_output_double = list(src = c(), dest = c(), weight = c())
index = 1
len = length(PPI_sig_network$src_id)
for (i in 1:len){
  if (PPI_sig_network$relation[i] == "Phy"){
    PPI_sig_network_output_double$src[index] = which(PPI_sig_network_index_double == PPI_sig_network$src_id[i])
    PPI_sig_network_output_double$dest[index] = which(PPI_sig_network_index_double == PPI_sig_network$dest_id[i])
    PPI_sig_network_output_double$weight[index] = 1
    PPI_sig_network_output_double$src[index + 1] = which(PPI_sig_network_index_double == PPI_sig_network$dest_id[i])
    PPI_sig_network_output_double$dest[index + 1] = which(PPI_sig_network_index_double == PPI_sig_network$src_id[i])
    PPI_sig_network_output_double$weight[index + 1] = 1
    index = index + 2
  } else{
    PPI_sig_network_output_double$src[index] = which(PPI_sig_network_index_double == PPI_sig_network$src_id[i])
    PPI_sig_network_output_double$dest[index] = which(PPI_sig_network_index_double == PPI_sig_network$dest_id[i])
    PPI_sig_network_output_double$weight[index] = 1
    index = index + 1
  }
}

PPI_sig_network_output_double = unique(data.frame(PPI_sig_network_output_double))
PPI_sig_network_output_double
#write.table(PPI_sig_network_output_double, "../data_out/wang_network.txt", sep = "\t", quote = F, row.names = FALSE, col.names = FALSE)
