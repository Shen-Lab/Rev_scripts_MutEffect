#! /usr/bin/env bash

mkdir ../data_out
Rscript net_trans.r < ../data_ori/PPI_sig_network > ../data_out/wang_network.txt
