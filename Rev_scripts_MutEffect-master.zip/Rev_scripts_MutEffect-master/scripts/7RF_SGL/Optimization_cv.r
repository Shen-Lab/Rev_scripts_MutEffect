#edited by Suping Deng on 01/17/2019

library(scales)
library(randomForest)
library(randomForestExplainer)
library(SGL)
library(pracma)
library(gsubfn)
library(arules)

 Optimization = function(dataset,label,RsCoverage, RsTree){
	p = RsTree
	label = sapply(label, as.numeric)
	feature_matrix_with_label = list(x = RsCoverage, y = label)
        cvFit  = cvSGL(feature_matrix_with_label, p, type = "logit")
        p_maxll = which.max(cvFit$lldiff)
        lambda = cvFit$lambdas[p_maxll]

        #Fit = SGL(feature_matrix_with_label, p, lambdas = cvFit$lambdas)
	Fit = SGL(feature_matrix_with_label, p, type = "logit",lambdas=lambda)
	#label_training_predicted = predictSGL(Fit, RsCoverage, 20)
	return(Fit)
}


