#! /usr/bin/env bash 

Rscript RF_SGL_cv.r <../data_out/feature_label_motif.txt    
