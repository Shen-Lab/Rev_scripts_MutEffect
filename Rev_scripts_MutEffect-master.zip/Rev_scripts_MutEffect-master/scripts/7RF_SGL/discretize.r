#edited by Suping Deng on 12/3/2018

#discretize th length of each rule into four percentiles in order to calculate the score for each motif
discretize = function(x, y){
  t = x / y
  if (t < 0.25){
    a = 4
  } else if ((t >= 0.25) & (t < 0.5)){
    a = 3
  } else if ((t >= 0.5) & (t < 0.75)){
    a = 2
  } else if ((t >= 0.75) & (t <= 1)){
    a = 1
  }
  return(a)
}


