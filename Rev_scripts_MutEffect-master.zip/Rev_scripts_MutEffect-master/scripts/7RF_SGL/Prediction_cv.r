#edited by Suping Deng on 12/3/2018

library(ggplot2)
library(scales)
library(randomForest)
library(randomForestExplainer)
library(SGL)
library(pracma)
library(gsubfn)
library(arules)


Prediction = function(model, test_RsCoverage, RsRemain){
	label_test_predicted = predictSGL(Fit, test_RsCoverage$a[,which(RsRemain == 1)], 1)
	rule_index = which(Fit$beta[,1] != 0)
	result = list()
	result$a = rule_index
	result$b = label_test_predicted
	result$c = test_RsCoverage
	return(result)
}


