#edited by Suping Deng on 11/30/2018

library(ggplot2)
library(scales)
library(randomForest)
library(randomForestExplainer)
library(SGL)
library(pracma)
library(gsubfn)
library(arules)

#read feature matrix
fea_label=read.table(file("stdin"), sep="\t", head=T,check.names=F)

#split fea_label into training and test data
#set.seed(123)
quantile=c(floor(nrow(fea_label)/5),nrow(fea_label))
fea = fea_label[,1:(ncol(fea_label)-1)]
motif_subclass=colnames(fea)
#motif_subclass0=colnames(fea)
#motif_subclass = sapply(motif_subclass0,function(p){s=sub('^.','',p);s})#delete "X" in front of the motif_subclass such as "X38_0_0_0",read.table(), check.names=F will not have this problem.
#names(motif_subclass)=c()
label = fea_label[,ncol(fea_label)]
X_test = fea[1:quantile[1],]
label_test =label[1:quantile[1]]
X_training= fea[(quantile[1]+1):nrow(fea_label),]
label_training = label[(quantile[1]+1):nrow(fea_label)]


# Decision path
source("decision_path.r")

# compute Rule_RScore
source("Rule_RScore.r")

source("Optimization.r")

source("Prediction.r")

source("ROC.r")

source("discretize.r")

source("Recover_Validation.r")


#RF is to generate the decision trees

# random forest prediction
RF = randomForest(x = X_training, y = as.factor(label_training), mtry = floor(log2(dim(X_training)[2])), ntree = 200, nodesize = 10, importance = TRUE)
label_predicted_test = predict(RF, X_test)

# new feature space for training set
RsResult = Rule_RScore(X_training, label_training, F)
RsResult_test = Rule_RScore(X_test, NA, T)
save(RsResult,file="../data_out/RsResult.RData")
#saveRDS(RsResult, "../data_out/RsResult.RData")

# train SGL model
Fit = Optimization(X_training, label_training, RsResult$a[,which(RsResult$c == 1)], RsResult$b[,which(RsResult$c == 1)])

# make prediction by SGL
PreResult = Prediction(Fit, RsResult_test, RsResult$c)
save(PreResult, file="../data_out/Prediction_Result.RData")
#saveRDS(PreResult, file="../data_out/Prediction_Result.RData")

# calculate AUC score
AUC = ROC(PreResult$b, label_test)

write.table(AUC, "../data_out/AUC_ROC.txt",sep="\t",row.names=F, col.names=F, quote=F)

# summarize rules
rule_interpret = Recover_Validation(PreResult$a, RsResult$b[,which(RsResult$c == 1)], RsResult$d)
save(rule_interpret, file="../data_out/rule_extract.RData")
#aveRDS(rule_interpret, file="../data_out/rule_extract.RData")
