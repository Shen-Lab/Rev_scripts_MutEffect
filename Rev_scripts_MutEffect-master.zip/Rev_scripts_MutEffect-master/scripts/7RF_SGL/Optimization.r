#edited by Suping Deng on 12/3/2018

library(scales)
library(randomForest)
library(randomForestExplainer)
library(SGL)
library(pracma)
library(gsubfn)
library(arules)

 Optimization = function(dataset,label,RsCoverage, RsTree){
	p = RsTree
	label = sapply(label, as.numeric)
	feature_matrix_with_label = list(x = RsCoverage, y = label)
#  cvFit  = cvSGL(feature_matrix_with_label, p, type = "linear")
#  lambda = cvFit$lambdas[20]
#  Fit = SGL(feature_matrix_with_label, p, lambdas = cvFit$lambdas)
	Fit = SGL(feature_matrix_with_label, p, type = "logit")
	label_training_predicted = predictSGL(Fit, RsCoverage, 20)
	return(Fit)
}


