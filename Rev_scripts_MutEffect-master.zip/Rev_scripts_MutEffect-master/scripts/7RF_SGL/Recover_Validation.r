library(ggplot2)
library(scales)
library(randomForest)
library(randomForestExplainer)
library(SGL)
library(pracma)
library(gsubfn)
library(arules)


# recover and restore all remained rules
Recover_Validation = function(rule_index, RsTree, path_store){
  rule_interpret = list()
  index = 1
  rule_class = matrix(0, ncol = length(rule_index), nrow = 1)
  rule_motif = matrix(0, nrow = length(rule_index), ncol = length(motif_subclass))
  colnames(rule_motif) = motif_subclass
  for (j in 1:length(rule_index)){
    tree_no = RsTree[rule_index[j]]
    tree = getTree(RF, tree_no)
    path = path_store[rule_index[j]]
    class = tree[path[[1]][length(path[[1]])], 6] - 1
    rule_class[1, j] = class
    if (class == 1){
      for (i in 1:(length(path[[1]]) - 1)){
        d = discretize(i, (length(path[[1]]) - 1))
        node = path[[1]][i]
        split_var = tree[node, 3]
        split_point = tree[node, 4]
        if (tree[node, 1] == path[[1]][i + 1]){ # calculate the score based on rank of the motif within a rule
          direction = "<"
          rule_motif[j, split_var] =  d

        } else{
          direction = ">"
          rule_motif[j, split_var] = d
        }
        # rule_motif[j, split_var] =  d 
        rule_temp = paste(colnames(rule_motif)[split_var], direction, split_point)
        if (i == 1){
          rule = rule_temp
        } else{
          rule = paste(rule, ";", rule_temp)
        }
      }
    }
    rule_interpret[[index]] = rule
    rule_interpret[[index]][2] = tree[path[[1]][length(path[[1]])], 6] - 1
    index = index + 1
  }
  result = list()
  result$a = rule_interpret # final rule set
  result$b = rule_motif # matrix of rules vs motifs
  result$c = rule_class # corresponding class (0 or 1)
  return(result)
}


