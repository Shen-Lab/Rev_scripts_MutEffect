#edited by Suping Deng on 11/30/2018

library(ggplot2)
library(scales)
library(randomForest)
library(randomForestExplainer)
library(SGL)
library(pracma)
library(gsubfn)
library(arules)

#read feature matrix
fea_label=read.table(file("stdin"), sep="\t", head=T,check.names=F)

#split fea_label into training and test data
#set.seed(123)
quintile=c(floor(nrow(fea_label)/5),nrow(fea_label))
fea = fea_label[,1:(ncol(fea_label)-1)]
motif_subclass=colnames(fea)
#motif_subclass0=colnames(fea)
#motif_subclass = sapply(motif_subclass0,function(p){s=sub('^.','',p);s})#delete "X" in front of the motif_subclass such as "X38_0_0_0",read.table(), check.names=F will not have this problem.
#names(motif_subclass)=c()
label = fea_label[,ncol(fea_label)]
X_test = fea[1:quintile[1],]
label_test =label[1:quintile[1]]
X_training= fea[(quintile[1]+1):nrow(fea_label),]
label_training = label[(quintile[1]+1):nrow(fea_label)]


# Decision path
source("decision_path.r")

# compute Rule_RScore
source("Rule_RScore.r")

source("Optimization_cv.r")

source("Prediction_cv.r")

source("ROC.r")

source("discretize.r")

source("Recover_Validation.r")


#RF is to generate the decision trees

# random forest prediction
RF = randomForest(x = X_training, y = as.factor(label_training), mtry = floor(log2(dim(X_training)[2])), ntree = 200, nodesize = 10, importance = TRUE)
label_predicted_test = predict(RF, X_test)

# new feature space for training set
RsResult = Rule_RScore(X_training, label_training, F)
RsResult_test = Rule_RScore(X_test, NA, T)
save(RsResult,file="../data_out/RsResult_cv.RData")
save(RsResult_test,file="../data_out/RsResult_test_cv.RData")
#saveRDS(RsResult, "../data_out/RsResult.rds")

# train SGL model
Fit = Optimization(X_training, label_training, RsResult$a[,which(RsResult$c == 1)], RsResult$b[,which(RsResult$c == 1)])

# make prediction by SGL
PreResult = Prediction(Fit, RsResult_test, RsResult$c)
save(PreResult, file="../data_out/Prediction_Result_cv.RData")
#saveRDS(PreResult, file="../data_out/Prediction_Result.rds")

# calculate AUC score
AUC = ROC(PreResult$b, label_test)

write.table(AUC, "../data_out/AUC_ROC_cv.txt",sep="\t",row.names=F, col.names=F, quote=F)

# summarize rules
rule_interpret = Recover_Validation(PreResult$a, RsResult$b[,which(RsResult$c == 1)], RsResult$d)
save(rule_interpret, file="../data_out/rule_extract_cv.RData")
#saveRDS(rule_interpret, file="../data_out/rule_extract.rds")

 gene_rule_all = rbind(RsResult$a[, PreResult$a], RsResult_test$a[, PreResult$a])
 write.table(gene_rule_all,"../data_out/gene_rule_all_cv.txt",sep="\t")
 gene_rule_CGC_candidate = gene_rule_all[which(dataset$label == 1),]
 dataset_CGC_candidate = dataset[which(dataset$label == 1),]
 CGC_position = c()
 for (i in 1:dim(gene_rule_CGC_candidate)[1]){
   if (length(which(CGC$Entrez.GeneId == rownames(dataset_CGC_candidate)[i])) != 0){
     CGC_position = c(CGC_position, i)
   }
 }
 gene_rule_temp = gene_rule_CGC_candidate[CGC_position,]
 dataset_CGC_temp = dataset_CGC_candidate[CGC_position, 1:470]
 CGC_out = c()
 for (i in 1:dim(gene_rule_temp)[1]){
   if (round(sum(dataset_CGC_temp[i,])) == sum(dataset_CGC_temp[i,])){
     CGC_out = c(CGC_out, i)
   }
 }
 CGC_position = c()
 for (i in 1:dim(dataset_original)[1]){
   if (length(which(CGC$Entrez.GeneId == rownames(dataset_original)[i])) != 0){
     CGC_position = c(CGC_position, i)
   }
 }
 X_CGC = dataset_original[CGC_position,]
 RsResult_CGC = Rule_RScore(X_CGC, matrix(1, nrow = dim(X_CGC)[1], ncol = 1), F)
 gene_CGC_rule = RsResult_CGC$a[, PreResult$a]
 write.table(gene_CGC_rule,"../data_out/gene_CGC_rule.txt",sep="\t")
 
 gene_motif_rule = matrix(0, nrow = dim(gene_rule)[1], ncol = dim(rule_motif)[2])
 rownames(gene_motif_rule) = rownames(gene_rule)
 colnames(gene_motif_rule) = colnames(rule_motif)
 for (i in 1: dim(gene_rule)[2]){
   covered_gene_position = which(gene_rule[, i] != 0)
   active_motif_position = which(rule_motif[i, ] != 0)
   if (length(covered_gene_position) != 0){
     for (j in 1:length(covered_gene_position)){
       gene_motif_rule[covered_gene_position[j], active_motif_position] = 1
     }
   }
 }
write.table(gene_motif_rule,"../data_out/gene_motif_rule_cv.txt",sep="\t")
