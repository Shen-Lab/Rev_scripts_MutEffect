#edited by Suping Deng on 12/3/2018

library(randomForest)
library(randomForestExplainer)


# Decision path
decision_path <- function(tree, child){   
	parent <- which(tree[,'left daughter']==child | tree[,'right daughter']==child)
	if( parent==1 ) return(c(1,child))
	return(c(decision_path(tree, child=parent),child))    
}


