#edited by Suping Deng on Dec. 1,2018
# Calculate AUC value
ROC = function(prediction, true){
	ROC_step = seq(0, 1, 1 / 1000)
	CP = length(which(true == 1))
	CN = length(which(true == 0))
	TPR = c()
	FPR = c()  
	for (m in 1:1001){
		threshold = ROC_step[m]
		TPR[m] = length(which(prediction > threshold & true == 1)) / CP
		FPR[m] = length(which(prediction > threshold & true == 0)) / CN
	}
	return(-trapz(FPR, TPR))
}

