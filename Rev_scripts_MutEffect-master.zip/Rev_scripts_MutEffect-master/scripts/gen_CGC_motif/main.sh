#! /usr/bin/env bash 
Rscript gen_CGC_motif.r < filename.txt
