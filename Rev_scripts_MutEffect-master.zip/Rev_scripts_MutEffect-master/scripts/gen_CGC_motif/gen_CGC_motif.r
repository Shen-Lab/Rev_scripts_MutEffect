#! /usr/bin/env Rscript

#edited by Suping Deng on 11/28/2018

library(AnnotationDbi)
library(org.Hs.eg.db)
library(R.utils)

#read data
f = scan(file("stdin"),what=character(0),sep="\t")#f[1] is Census.csv, f[2] is motif

motif = read.table(f[2])

CGC = read.csv(f[1], fill = TRUE, header = T)

#get intersection gene ID
names_CGC = as.character(CGC[,1])
names_CGC_ID = c()
for (i in 1:length(names_CGC)){
  name_temp_ID = mget(as.character(names_CGC[i]), revmap(org.Hs.egSYMBOL), ifnotfound = NA)[[1]][1]
  names_CGC_ID = c(names_CGC_ID, name_temp_ID)
}
names_CGC_ID = names_CGC_ID[-which(is.na(names_CGC_ID) == TRUE)]


names_motif_ID = unique(c(motif[, 1], motif[, 2], motif[, 3]))
names_intersect_ID = intersect(names_motif_ID, names_CGC_ID)

#get motifs containing driver genes
motif_subclass=unique(paste(motif$ID,motif$subID, sep ="_"))
source('motif_matrix.r')
CGC_gene_motif = motif_matrix(names_intersect_ID,motif)
CGC_gene_motif = cbind(CGC_gene_motif, rep(1, nrow(CGC_gene_motif)))
write.table(CGC_gene_motif,"../data_out/CGC_gene_motif.txt",sep="\t",quote=F)

