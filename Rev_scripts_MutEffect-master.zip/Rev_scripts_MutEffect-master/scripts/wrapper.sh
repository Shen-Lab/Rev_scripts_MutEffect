#! /usr/bin/env bash
#network transformation
cd 1net_trans/
./main.sh
cd ..

#Identifying motif
cd 2find_motif/
find_motif.sh
cd ..

#Process motif
cd 3proc_motif/
./main.sh
cd ..

#Statistical analysis of motifs to find hot motifs
cd 4stat_motif/
./main.sh
cd ..

#Generate feature matrix (based on motif)
cd 5gen_fea_matrix/
./main_resam.sh
cd ..

#Random forest in python to get a RandomForest model and partitioned dataset
cd 6RandomForest_py/
./main.sh
cd ..

#Rule extraction by random forest and sparse group lasso in R
cd 7RF_SGL/
./main.sh
cd ..

#Find overlap motifs between those by statistical analysis and those by rule extraction
cd 8Overlap_hot_motif
./main.sh
cd ..

#Draw figure of motif scores by rule extraction
cd 9draw_motif_score/
./main.sh
cd ..

#Plot precision_recall curve, AUC_ROC curve
cd 10Plot_PC_ROC_py
./main.sh
cd ..

#Compare with centrality-based features
#Generate centrality-based feature matrix
cd 11Cmp_Centrality/1Gen_Fea_Centrality
./main.sh

#Generate centrality-based random forest model
cd ../2RF_model_cen/
./main.sh

#Plot figures to compare two types of features
cd ../3PLot_cmp/
./main.sh

