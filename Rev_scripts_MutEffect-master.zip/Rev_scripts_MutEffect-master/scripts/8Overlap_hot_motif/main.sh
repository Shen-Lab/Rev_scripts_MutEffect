#! /usr/bin/env bash 

Rscript overlap_hot_motif.r < filename.txt  
