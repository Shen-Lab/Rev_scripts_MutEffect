#edited by Suping Deng on 11/30/2018
library(randomForest)
library(randomForestExplainer)
library('SGL')


#read predicted hot motifs by RF+SFL
f=scan(file("stdin"), what=character(0),sep="\t")#f[1] is rule_extract.RData, f[2] is hot_motif_stat.

load(f[1]) 
rule_extract = rule_interpret 
motif_score_extract = colSums(rule_extract$b)## final score for each motif in the extracted rules by RF+SGL
motif_stat0 = read.table(f[2],sep="\t",head=T) 
motif_stat = as.vector(motif_stat0[,1])
names(motif_stat) = row.names(motif_stat0)
motif_extract_pos = which(motif_score_extract != 0)
motif_stat_pos = which(motif_stat != "None")
motif_extract_stat = intersect(names(motif_extract_pos), names(motif_stat_pos))
write.table(motif_extract_stat,"../data_out/overlap_hotmotif.txt",sep="\t",quote=F,col.names=F,row.names=F) 


