#! /usr/bin/env bash

#cd ../data_out
#awk -v FS=' ' -v OFS='\t' '{$1="";print$0}' feature_label_motif.txt > feature_label_motif_py0.txt 
#sed '1d' feature_label_motif_py0.txt > feature_label_motif_py.txt
#cd ../6RandomForest_py/
source activate name_of_my_env
python RandomForest_new0.py  ../data_out/feature_label_motif_py.txt 
#python RandomForest_new.py < filename.txt
source deactivate name_of_my_env
