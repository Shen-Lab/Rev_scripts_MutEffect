from sys import argv
from sys import stdin
import pandas as pd
import math
import numpy as np
from numpy import random
from scipy.misc import comb
import matplotlib.pyplot as plt
from scipy.stats import pearsonr as prs
from scipy.spatial.distance import euclidean as dis
from sklearn.metrics import mean_squared_error as mse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.externals import joblib
from sklearn.metrics.pairwise import pairwise_kernels
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
import sys


class classification(object):




	def maincalculation(self, feature_matrix, label):
		# read data and labels
		numRow =np.shape(feature_matrix)[0]
		quintile = [int(np.shape(feature_matrix)[0]/5),numRow] 
		X_test = feature_matrix[:quintile[0], :]
		label_test = label[:quintile[0]]
		X_training = feature_matrix[quintile[0]:quintile[1], :]
		label_training = label[quintile[0]:quintile[1]]

		# initiate RF classifier
		regr = RandomForestClassifier(n_jobs=20) 

		
		# set hyperparameters
		num_estimator = [50, 100, 200]
		max_feature = ["sqrt", "log2"]
		min_samples_leaf = [10, 50]
		tuned_parameters = [{'n_estimators': num_estimator,'max_features':max_feature,'min_samples_leaf':min_samples_leaf}]
		n_folds = 4
		RF_regressor = GridSearchCV(regr, tuned_parameters, cv=n_folds, scoring = 'average_precision')
		RF_regressor.fit(X_training,label_training)


		# save model and parameters
		filename = '../data_out/RandomForest_motif.joblib.pkl'
		joblib.dump(RF_regressor, filename, compress = 3)
		np.savetxt('../data_out/X_training_motif.txt',X_training, delimiter = '\t')
		np.savetxt('../data_out/X_test_motif.txt', X_test, delimiter = '\t')
		np.savetxt('../data_out/label_training_motif.txt', label_training, delimiter = '\t', fmt = '%i')
		np.savetxt('../data_out/label_test_motif.txt', label_test, delimiter = '\t', fmt = '%i')

		# self.ROC_plot(label_predicted_test, label_test, RMSE)

if __name__ == '__main__':

	f = stdin.readline()
        #f = sys.argv[0]
	f =f.strip('\n')
	#f1 = "../data_out/feature_label_motif_py.txt"
	feature_label = np.loadtxt(f, delimiter ='\t',dtype=int)
	d = np.shape(feature_label)
	ncol = d[1]	
	feature = feature_label[:,0:(ncol-1)]
	label = feature_label[:,(ncol-1)]
	classification = classification()
	classification.maincalculation(feature, label)
