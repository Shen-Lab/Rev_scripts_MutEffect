#! /usr/bin/env bash 

Rscript draw_motif_score.r < filename.txt 
