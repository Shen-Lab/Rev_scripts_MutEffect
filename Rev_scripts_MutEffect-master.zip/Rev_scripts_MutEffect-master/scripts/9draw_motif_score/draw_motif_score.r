#edited by Suping Deng on 12/3/2018

library(ggplot2)

#read data: motif_subclass from motif.txt, motif_score from rule_extract.txt
f<-scan(file("stdin"),what=character(0),sep="\t")# f[1] is motif, f[2] is rule_extract.RData
# draw motif_score figure
motif =read.table(f[1])
motif_subclass=unique(paste(motif$ID,motif$subID, sep ="_"))

load(f[2])
rule_extract = rule_interpret
motif_score_extract = colSums(rule_extract$b)## final score for each motif in the extracted rules by RF+SGL

df = data.frame(motif = motif_subclass, score = motif_score_extract)
p = ggplot(df, mapping = aes(x = reorder(motif, score), y = score)) + geom_bar(stat="identity")
ggsave(file = "../data_out/motif_score.eps", family = "sans", width = 12, height = 6)

