#! /usr/bin/env Rscript

#edited by Suping Deng on 12/2/2018


motif_matrix = function(x,motif){
motif_subclass = unique(paste(motif$ID, motif$subID, sep = "_"))
gene_motif = matrix(0, nrow = length(x), ncol = length(motif_subclass))
colnames(gene_motif) = motif_subclass
rownames(gene_motif) = x
for (i in 1:dim(gene_motif)[1]){
    id_temp = c()
    for (k in 1:3){
      if (is.element(rownames(gene_motif)[i], motif[, k]) == TRUE){
        id_temp = c(id_temp, which(motif[, k] == x[i]))
      }
    }
    col_temp = c()
    for (j in 1:length(id_temp)){
      col_temp = c(col_temp, which(colnames(gene_motif) == paste(motif$ID[id_temp[j]], motif$subID[id_temp[j]], sep = "_")))
    }
    col_temp = unique(col_temp)
    gene_motif[i, col_temp] = 1
  }
  return(gene_motif)
}


