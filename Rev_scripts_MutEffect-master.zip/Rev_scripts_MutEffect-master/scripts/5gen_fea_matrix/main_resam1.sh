#!/usr/bin/env bash 
Rscript gen_fea_matrix_resam1.r < filename.txt 
