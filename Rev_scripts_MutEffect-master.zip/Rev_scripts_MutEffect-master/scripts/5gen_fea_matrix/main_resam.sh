#!/usr/bin/env bash 
Rscript gen_fea_matrix_resam.r < filename.txt 
