#edited by Suping Deng on 11/29/2018


library(AnnotationDbi)
library(org.Hs.eg.db)
library(DMwR)
library(igraph)

#read data
f = scan(file("stdin"),what=character(0),sep="\t")#f[1] is Census.csv, f[2] is motif

motif = read.table(f[2])

CGC = read.csv(f[1], fill = TRUE, header = T)
names_CGC = as.character(CGC[,1])
names_CGC_ID = c()
for (i in 1:length(names_CGC)){
  name_temp_ID = mget(as.character(names_CGC[i]), revmap(org.Hs.egSYMBOL), ifnotfound = NA)[[1]][1]
  names_CGC_ID = c(names_CGC_ID, name_temp_ID)
}
names_CGC_ID = names_CGC_ID[-which(is.na(names_CGC_ID) == TRUE)]


names_motif_ID = unique(c(motif[, 1], motif[, 2], motif[, 3]))
names_intersect_ID = intersect(names_motif_ID, names_CGC_ID)

names_CGC_noMotif_ID = setdiff(names_CGC_ID, names_intersect_ID)
write.table(names_CGC_noMotif_ID,"../data_out/names_CGC_noMotif_ID.txt",sep='\t',quote=F,row.names=F,col.names=F)
names_unlabel_ID = setdiff(names_motif_ID, names_CGC_ID)

writeLines(as.character(names_intersect_ID),"../data_out/names_intersect_ID.txt",sep="\n")
writeLines(as.character(names_unlabel_ID),"../data_out/names_unlabel_ID.txt",sep="\n") 
#complicated features
real_length_zero = length(names_unlabel_ID)
real_length_one = length(names_intersect_ID)
real_length_total = real_length_zero + real_length_one

#oversampleing positive samples to make that the number of positive samples equals to the nubmer of negative samples 
num_resam = 500- real_length_one
set.seed(123)
one_pos_resam = sample(names_intersect_ID,num_resam,replace=T)

one_pos_total = c(names_intersect_ID, one_pos_resam)
set.seed(123)
one_pos_resam = sample(names_intersect_ID,num_resam,replace=T)
set.seed(123)
zero_pos_total = sample(names_unlabel_ID,500)
#zero_pos_total = as.character(zero_pos_total)
source("motif_matrix.r")

fea_motif_one = motif_matrix(one_pos_total,motif)
fea_motif_zero = motif_matrix(zero_pos_total,motif)

fea_label_motif_one = cbind(fea_motif_one, rep(1,500))
fea_label_motif_zero = cbind(fea_motif_zero,rep(0,500))

fea_label_motif0 = rbind(fea_label_motif_one, fea_label_motif_zero)
rownames(fea_label_motif0)=paste("R",1:1000,sep="")

#shuffle the matrix
ptb_rowname = rownames(fea_label_motif0)
for (i in 1:50) {
set.seed(123)
ptb_rowname = sample(ptb_rowname, 1000)

}

fea_label_motif = fea_label_motif0[ptb_rowname,]
colnames(fea_label_motif)[ncol(fea_label_motif)] = "label"
#fea_label_motif
dim(fea_label_motif)
write.table(fea_label_motif,"../data_out/feature_label_motif1.txt",sep="\t",quote=F)
write.table(fea_label_motif,"../data_out/feature_label_motif_py1.txt",sep="\t",quote=F,row.names=F,col.names=F)
  



