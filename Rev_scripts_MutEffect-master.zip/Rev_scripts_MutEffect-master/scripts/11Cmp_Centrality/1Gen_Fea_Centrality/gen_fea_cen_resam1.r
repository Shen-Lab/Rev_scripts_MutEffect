library(AnnotationDbi)
library(org.Hs.eg.db)
library(DMwR)
library(igraph)

#read data
f = scan(file("stdin"), what=character(0),sep="\t") #f[1] is PPI_sig_network file, f[2] is names_intersect_ID.txt,f[3] is names_unlabel_ID.txt.
PPI_sig_network = read.table(f[1], sep = ' ', header = TRUE)
names_intersect_ID = readLines(f[2])
names_unlabel_ID = readLines(f[3]) 

# convert PPI network to adjancency network to calculate centrality
PPI_sig_network_igraph = graph_from_data_frame(cbind(PPI_sig_network$src_id, PPI_sig_network$dest_id), directed = F)

# search seven centrality features for every node
eigen_c = as.data.frame(eigen_centrality(PPI_sig_network_igraph))
closeness_c = as.data.frame(closeness(PPI_sig_network_igraph))
betweenness_c = as.data.frame(betweenness(PPI_sig_network_igraph))
authority_c = as.data.frame(authority_score(PPI_sig_network_igraph))
degree_c = as.data.frame(degree(PPI_sig_network_igraph))
pagerank_c = as.data.frame(page_rank(PPI_sig_network_igraph)$vector)
burtconstraint_c = as.data.frame(constraint(PPI_sig_network_igraph))

# feature matrix contains all genes
feature_cen_all = cbind(eigen_c[, 1], closeness_c, betweenness_c, authority_c[, 1], degree_c, pagerank_c, burtconstraint_c)
feature_cen_all = as.matrix(feature_cen_all)

# generate feature matrix based on centrality

feature_cen_names = c("eigen", "closeness", "betweenness", "authority", "degree", "pagerank", "burt")

#complicated features
real_length_zero = length(names_unlabel_ID)
real_length_one = length(names_intersect_ID)
real_length_total = real_length_zero + real_length_one

#oversampleing positive samples to make that the number of positive samples equals to the nubmer of negative samples 
num_resam = 500- real_length_one
set.seed(123)
one_pos_resam = sample(names_intersect_ID,num_resam,replace=T)

one_pos_total = c(names_intersect_ID, one_pos_resam)
set.seed(123)
one_pos_resam = sample(names_intersect_ID,num_resam,replace=T)
set.seed(123)
zero_pos_total = sample(names_unlabel_ID,500)


# fetch only matched genes which are in motifs
get_feature_cen = function(x){
   x_cen = matrix(0,nrow = length(x),ncol=ncol(feature_cen_all))
  for (i in 1:length(x)){
    name_temp = x[i]
    x_cen[i,] = feature_cen_all[name_temp,]
  }
  return(x_cen)
}


fea_cen_one = get_feature_cen(one_pos_total)
fea_cen_zero = get_feature_cen(zero_pos_total)

fea_label_cen_one = cbind(fea_cen_one, rep(1,length(one_pos_total)))
fea_label_cen_zero = cbind(fea_cen_zero,rep(0,length(zero_pos_total)))

fea_label_cen0 = rbind(fea_label_cen_one, fea_label_cen_zero)
rownames(fea_label_cen0)=paste("R",1:nrow(fea_label_cen0),sep="")

fea_label_cen_one = cbind(fea_cen_one, rep(1,500))
fea_label_cen_zero = cbind(fea_cen_zero,rep(0,500))

fea_label_cen0 = rbind(fea_label_cen_one, fea_label_cen_zero)
rownames(fea_label_cen0)=paste("R",1:1000,sep="")

#shuffle the matrix
ptb_rowname = rownames(fea_label_cen0)
for (i in 1:50) {
set.seed(123)
ptb_rowname = sample(ptb_rowname, 1000)

}

fea_label_cen = fea_label_cen0[ptb_rowname,]
colnames(fea_label_cen) = c(feature_cen_names,"label")
#fea_label_centrality
write.table(fea_label_cen,"../../data_out/feature_label_cen1.txt",sep="\t",quote=F)
write.table(fea_label_cen,"../../data_out/feature_label_cen_py1.txt",sep="\t",quote=F,row.names=F,col.names=F)

