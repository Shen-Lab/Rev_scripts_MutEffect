#!/usr/bin/env bash 

Rscript gen_fea_cen_resam1.r < filename.txt 
