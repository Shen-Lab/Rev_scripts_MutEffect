#!/usr/bin/env bash 

Rscript gen_fea_cen_resam.r < filename.txt 
