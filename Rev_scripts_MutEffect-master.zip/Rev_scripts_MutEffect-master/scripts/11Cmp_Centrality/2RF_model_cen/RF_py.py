#edited by Suping Deng on Dec. 10,2018
from sys import argv
import pandas as pd
import math
import numpy as np
from numpy import random
from scipy.misc import comb
import matplotlib.pyplot as plt
from scipy.stats import pearsonr as prs
from scipy.spatial.distance import euclidean as dis
from sklearn.metrics import mean_squared_error as mse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.externals import joblib
from sklearn.metrics.pairwise import pairwise_kernels
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler



class classification(object):




	def maincalculation(feature_label):# the last column of feature_label is label
		# read data and labels
		numRow = len (feature_label)
		numCol = len(feature_label[0])
		feature = feature_label[:,1:(numCol-1)]
		label = feature_label[:,numCol]
		numRow = len (feature_label)
		quintile = [int(numRow/5),len]
		X_training = feature_label[:quintile[0], :]
		label_training = label[:quintile[0]]
		X_test = feature_label[quintile[0]:quintile[1], :]
		label_test = label[quintile[0]:quintile[1]]

		# initiate RF classifier
		regr = RandomForestClassifier(n_jobs=20) 

		
		# set hyperparameters
		num_estimator = [50, 100, 200]
		max_feature = ["sqrt", "log2"]
		min_samples_leaf = [10, 50]
		tuned_parameters = [{'n_estimators': num_estimator,'max_features':max_feature,'min_samples_leaf':min_samples_leaf}]
		n_folds = 4
		RF_regressor = GridSearchCV(regr, tuned_parameters, cv=n_folds, scoring = 'average_precision')
		RF_regressor.fit(X_training,label_training)


		# save model and parameters
		filename = '../../data_out/RandomForest_cen.joblib.pkl'
		joblib.dump(RF_regressor, filename, compress = 3)
		#np.savetxt('../data_out/X_training.txt',X_training, delimiter = '\t')
		np.savetxt('../../data_out/X_test_cen.txt', X_test, delimiter = '\t')
		#np.savetxt('../data_out/label_training.txt', label_training, delimiter = '\t', fmt = '%i')
		#np.savetxt('../../data_out/label_test_cen.txt', label_test, delimiter = '\t', fmt = '%i')

		# self.ROC_plot(label_predicted_test, label_test, RMSE)

if __name__ == '__main__':

	feature_label = pd.read_table(sys.stdin, delimiter = "\t", index_col=0)
	classification = classification()
	classification.maincalculation(feature_label)



        label_predicted_test_RandomForest = model_RandomForest.predict(X_test)
        scores_test_RandomForest = model_RandomForest.predict_proba(X_test)
        #print model_RandomForest.best_estimator_
        np.savetxt("../data_out/model_RandomForest.best_estimator_cen.txt",model_RandomForest.best_estimator_,fmt='%s')
	
