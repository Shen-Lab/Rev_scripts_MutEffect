from __future__ import division
import numpy as np
import sys
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.externals import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import pairwise_kernels
from sklearn.metrics import average_precision_score
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import f1_score
import os


if __name__ == '__main__':
	# read data
	f0 = sys.stdin.readlines()
	f = []
	for line in f0:
        	f.append(line.strip('\n'))
	#f[0] is X_test_motif.txt,f[1] is X_test_cen.txt,f[2] is label_test_motif.txt,f[3] is label_test_cen.txt,f[4] is RandomForest_motif.joblib.pkl, f[5] is RandomForest_cen.joblib.pkl


	X_test_motif = np.loadtxt(f[0], delimiter = '\t')
	X_test_cen = np.loadtxt(f[1], delimiter = '\t')
	label_test_motif = np.loadtxt(f[2], delimiter = '\t')
	label_test_cen = np.loadtxt(f[3], delimiter = '\t')


		
	model_RandomForest_motif = joblib.load(f[4])
	label_predicted_test_RandomForest_motif = model_RandomForest_motif.predict(X_test_motif)
	scores_test_RandomForest_motif = model_RandomForest_motif.predict_proba(X_test_motif)
	model_RandomForest_cen = joblib.load(f[5])
	label_predicted_test_RandomForest_cen = model_RandomForest_cen.predict(X_test_cen)
	scores_test_RandomForest_cen = model_RandomForest_cen.predict_proba(X_test_cen)
	
	AUC_RandomForest_motif = roc_auc_score(label_test_motif, scores_test_RandomForest_motif[:, 1])
	fpr_RandomForest_motif, tpr_RandomForest_motif, thresholds_RandomForest_motif = roc_curve(label_test_motif, scores_test_RandomForest_motif[:, 1], pos_label = 1)
	AUC_RandomForest_cen = roc_auc_score(label_test_cen, scores_test_RandomForest_cen[:, 1])
	fpr_RandomForest_cen, tpr_RandomForest_cen, thresholds_RandomForest_cen = roc_curve(label_test_cen, scores_test_RandomForest_cen[:, 1], pos_label = 1)

	plt.plot(fpr_RandomForest_motif, tpr_RandomForest_motif, label = 'RF AUCROC (AUC = %0.4f)' % AUC_RandomForest_motif)
	plt.plot(fpr_RandomForest_cen, tpr_RandomForest_cen, label = 'RF AUCROC Cui et al.(AUC = %0.4f)' % AUC_RandomForest_cen)
	plt.plot([0, 1], [0, 1], 'k--')
	plt.xlim([0.0, 1.0])
	plt.ylim([0.0, 1.0])
	plt.xlabel('False Positive Rate')
	plt.ylabel('True Positive Rate')
	plt.title("Classification")
	plt.legend(loc = "lower right") 
	plt.savefig('../../data_out/heldout_ROC_cmp.eps', format='eps', dpi=1000)
	plt.clf()

	precision_RandomForest_motif, recall_RandomForest_motif, thresholds_RandomForest_motif = precision_recall_curve(label_test_motif, scores_test_RandomForest_motif[:, 1], pos_label = 1)
	AUC_PC_RandomForest_motif = average_precision_score(label_test_motif, scores_test_RandomForest_motif[:, 1])

	plt.plot(recall_RandomForest_motif, precision_RandomForest_motif, label = 'RF AUCPC (AUC = %0.4f)' % AUC_PC_RandomForest_motif)

	precision_RandomForest_cen, recall_RandomForest_cen, thresholds_RandomForest_cen = precision_recall_curve(label_test_cen, scores_test_RandomForest_cen[:, 1], pos_label = 1)
	AUC_PC_RandomForest_cen = average_precision_score(label_test_cen, scores_test_RandomForest_cen[:, 1])

	plt.plot(recall_RandomForest_cen, precision_RandomForest_cen, label = 'RF AUCPC Cui et al (AUC = %0.4f)' % AUC_PC_RandomForest_cen)

	# plt.plot([0, 1], [0, 1], 'k--')
	plt.xlim([0.0, 1.0])
	plt.ylim([0.0, 1.0])
	plt.xlabel('Recall')
	plt.ylabel('Precision')
	plt.title("Classification")
	plt.legend(loc = "lower right") 
	plt.savefig('../../data_out/heldout_PC_cmp.eps', format='eps', dpi=1000)
	plt.clf()



