#! /usr/bin/env bash

source activate name_of_my_env
python plot_curve_cmp.py < filename.txt 
source deactivate name_of_my_env

