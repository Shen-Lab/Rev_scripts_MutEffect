#! /usr/bin/env bash

source activate name_of_my_env
python plot_curve_cmp1.py < filename1.txt 
source deactivate name_of_my_env

