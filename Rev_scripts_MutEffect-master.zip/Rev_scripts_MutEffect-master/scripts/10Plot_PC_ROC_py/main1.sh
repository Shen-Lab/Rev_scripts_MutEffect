#! /usr/bin/env bash 
source activate name_of_my_env
python Plot_PRC_ROC1.py < filename1.txt 
source deactivate name_of_my_env
