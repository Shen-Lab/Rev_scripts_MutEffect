from __future__ import division
import numpy as np
import sys
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.externals import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import pairwise_kernels
from sklearn.metrics import average_precision_score
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import f1_score
import os

if __name__ == '__main__':
	#read data
	f0 = sys.stdin.readlines()# f[0] is X_test.txt,f[1] is label_test.txt, f[2] is RandomForest_motif.joblib.pkl. 
	f =[]
	for line in f0:
		f.append(line.strip('\n'))
	
	
	X_test = np.loadtxt(f[0],delimiter = '\t')
	label_test = np.loadtxt(f[1], delimiter = '\t')


	filename_RandomForest = f[2]
	model_RandomForest = joblib.load(filename_RandomForest)
	label_predicted_test_RandomForest = model_RandomForest.predict(X_test)
	scores_test_RandomForest = model_RandomForest.predict_proba(X_test)
	print model_RandomForest.best_estimator_ 
	np.savetxt("../data_out/model_RandomForest.best_estimator.txt",model_RandomForest.best_estimator_,fmt='%s')
	
	AUC_RandomForest = roc_auc_score(label_test, scores_test_RandomForest[:, 1])
	fpr_RandomForest, tpr_RandomForest, thresholds_RandomForest = roc_curve(label_test, scores_test_RandomForest[:, 1], pos_label = 1)

	#Plot AUC_ROC 
	plt.plot(fpr_RandomForest, tpr_RandomForest, label = 'RF ROC (AUC = %0.4f)' % AUC_RandomForest)


	plt.plot([0, 1], [0, 1], 'k--')
	plt.xlim([0.0, 1.0])
	plt.ylim([0.0, 1.0])
	plt.xlabel('False Positive Rate')
	plt.ylabel('True Positive Rate')
	plt.title("Classification")
	plt.legend(loc = "lower right") 
	plt.savefig('../data_out/heldout_ROC.eps', format='eps', dpi=1000)
	plt.clf()

	# Plot Precision-recall (PC) curve
# plt.plot([0, 1], [0, 1], 'k--')
        precision_RandomForest, recall_RandomForest, thresholds_RandomForest = precision_recall_curve(label_test, scores_test_RandomForest[:, 1], pos_label = 1)
        AUC_PC_RandomForest = average_precision_score(label_test, scores_test_RandomForest[:, 1])
	plt.plot(recall_RandomForest, precision_RandomForest, label = 'RF PC (AUC = %0.4f)' % AUC_PC_RandomForest)
	plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.0])
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title("Classification")
        plt.legend(loc = "lower right")
        plt.savefig('../data_out/heldout_PC.eps', format='eps', dpi=1000)
        plt.clf()

