#! /usr/bin/env bash 
source activate name_of_my_env
python Plot_PRC_ROC.py < filename.txt 
source deactivate name_of_my_env
