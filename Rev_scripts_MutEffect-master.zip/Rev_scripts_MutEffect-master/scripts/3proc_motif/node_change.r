# 20170310 by Haoran Chen
#edited by Suping Deng on 12/5/2018

# function for exchange nodes in motif
node_change = function(matrix, start, end){
  temp = matrix[start,]
  matrix[start,] = matrix[end,]
  matrix[end,] = temp
  temp = matrix[, start]
  matrix[, start] = matrix[, end]
  matrix[, end] = temp
  return(matrix)
}


