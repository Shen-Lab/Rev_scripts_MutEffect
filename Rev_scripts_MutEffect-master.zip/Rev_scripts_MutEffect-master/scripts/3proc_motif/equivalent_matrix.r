# 20170310 by Haoran Chen
#edited by Suping Deng on 12/5/2018
library(AnnotationDbi)
library(org.Hs.eg.db)
library(R.utils)



equivalent_matrix = function(matrix1, matrix2){
  if (matequal(node_change(node_change(matrix2, 1, 2), 1, 3), matrix1)){
    return(list(TRUE, 1, 2, 3))
  }
  if (matequal(node_change(node_change(matrix2, 1, 3), 1, 2), matrix1)){
    return(list(TRUE, 1, 3, 2))
  }
  for (j in 1:(motif_node - 1)){
    for (k in (j + 1):motif_node){
      if (matequal(node_change(matrix2, j, k), matrix1)){
        return(list(TRUE, j, k))
      }
    }
  }
  return(FALSE)
}


