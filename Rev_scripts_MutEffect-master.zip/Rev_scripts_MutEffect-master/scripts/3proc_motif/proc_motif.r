# 20170310 by Haoran Chen
#edited by Suping Deng on 11/28/2018
library(AnnotationDbi)
library(org.Hs.eg.db)
library(R.utils)


# Read motif info data
f<-scan(file("stdin"),what=character(0),sep="\t")#f[1]is OUT file; f[2] is MEMBERS file.
motif_node = 3
motif_id = c()
motif_3_double.info = scan(f[1], what = character(0), sep = "")
motif_num = as.integer(motif_3_double.info[which(motif_3_double.info == "Full")[1] + 3])
index = which(motif_3_double.info == "[MILI]")[1] + 1
for (i in 1:motif_num){
  motif_id[i] = motif_3_double.info[index + (i - 1) * (motif_node ^ 2 + 7)]
}

# Read motif members data
motif_3_double.data = scan(f[2], what = character(0), sep = "")
subgraph_loc= which(motif_3_double.data == "subgraph")
subgraph_motif = c()

# Check if a subgraph is motif 
for (i in 1:length(subgraph_loc)){
  subgraph_motif[i] = FALSE
  if (is.element(motif_3_double.data[subgraph_loc[i] + 3], as.integer(motif_id))){
    subgraph_motif[i] = TRUE
  }
}

# Store motif from MFINDER output
motif = c()
index = 1
count = 0
for (i in 1:length(subgraph_motif)){
  if (subgraph_motif[i] == TRUE){
    start = subgraph_loc[i] + 13
    if (i == length(subgraph_motif)){
      end = length(motif_3_double.data)
    } else{
      end = subgraph_loc[i + 1] - 1
    }
    for (j in start:end){
      if (index == 1){
        motif$member$one = c(motif$member$one, as.integer(motif_3_double.data[j]))
        index = index + 1
      } else if(index == 2){
        motif$member$two = c(motif$member$two, as.integer(motif_3_double.data[j]))
        index = index + 1
      } else if(index == 3){
        motif$member$three = c(motif$member$three, as.integer(motif_3_double.data[j]))
        index = 1
        count = count + 1
        motif$ID[count] = motif_3_double.data[subgraph_loc[i] + 3]
      }
    }
  }
}

motif = data.frame(motif)

# function for exchange nodes in motif
source("node_change.r")
source("matequal.r")

source("binary_matrix.r")
source("equivalent_matrix.r")


# Match motif members with its subgraph ID
for (i in 1:length(motif$ID)){
  binary_ID = binary_matrix(motif$ID[i])
  binary_ori = matrix(0, nrow=motif_node, ncol=motif_node) 
  for (j in 1:(motif_node - 1)){
    for (k in (j + 1):motif_node){
      if (length(which(PPI_sig_network_output_double$src == motif[i, j] & PPI_sig_network_output_double$dest == motif[i, k])) > 0){
        binary_ori[j, k] = 1
      }
      if (length(which(PPI_sig_network_output_double$dest == motif[i, j] & PPI_sig_network_output_double$src == motif[i, k])) > 0){
        binary_ori[k, j] = 1
      }
      if (matequal(binary_ID, binary_ori) == FALSE){
        judge = equivalent_matrix(binary_ID, binary_ori)
        if (judge[[1]][1] == TRUE){
          temp = motif[i, judge[[2]][1]]
          motif[i, judge[[2]][1]] = motif[i, judge[[3]][1]]
          motif[i, judge[[3]][1]] = temp 
        }
      }
    }
  }
}

# Map motif back to real gene ID
for (i in 1:length(motif$ID)){
  for (j in 1:3){
    motif[i, j] = PPI_sig_network_index_double[motif[i, j]]
  }
}


# Get motif path function (negative path, bi-directed path)
for (i in 1:length(motif$ID)){
  ## Original binary matrix
  binary_ori = matrix(0, nrow=motif_node, ncol=motif_node) 
  str = strsplit(intToBin(as.integer(as.character(motif$ID[i]))), split = "")
  index = length(str[[1]])
  for (j in 1:motif_node){
    for (k in 1:motif_node){
      if (index != 0){
        binary_ori[j, k] = as.integer(str[[1]][index])
        index = index - 1
      } else{
        binary_ori[j, k]= 0
      }
    }
  }
  ## Negative path
  binary_neg = matrix(0, nrow=motif_node, ncol=motif_node)
  for (j in 1:(motif_node - 1)){
    for (k in (j + 1):motif_node){
      if (is.element("Neg", PPI_sig_network$relation[which(PPI_sig_network$src_id == motif[i, j] & PPI_sig_network$dest_id == motif[i, k])])){
        if (binary_ori[j, k] == 1){
          binary_neg[j, k] = 1
        }
      }
      if (is.element("Neg", PPI_sig_network$relation[which(PPI_sig_network$src_id == motif[i, k] & PPI_sig_network$dest_id == motif[i, j])])){
        if (binary_ori[k, j] == 1){
          binary_neg[k, j] = 1
        }
      }
    }
  }
  index = 0
  decimal_neg = 0
  for (j in motif_node:1){
    for (k in motif_node:1){
      index = index + 1
      decimal_neg = decimal_neg + binary_neg[j, k] * 2 ^ (motif_node ^ 2 - index) 
    }
  }
  motif$negative.path[i] = decimal_neg
  
  
  ## Physical paths or Pos paths for bi-directed paths 
  binary_phy = matrix(0, nrow=motif_node, ncol=motif_node)
  binary_pos = matrix(0, nrow=motif_node, ncol=motif_node)
  for (j in 1:(motif_node - 1)){
    for (k in (j + 1):motif_node){
      if (binary_ori[j, k] == 1 & binary_ori[k, j] == 1){
        if (is.element("Phy", PPI_sig_network$relation[which(PPI_sig_network$src_id == motif[i, k] & PPI_sig_network$dest_id == motif[i, j])]) | is.element("Phy", PPI_sig_network$relation[which(PPI_sig_network$dest_id == motif[i, k] & PPI_sig_network$src_id == motif[i, j])])){
          binary_phy[j, k] = 1
          binary_phy[k, j] = 1
        }
        if (is.element("Pos", PPI_sig_network$relation[which(PPI_sig_network$src_id == motif[i, k] & PPI_sig_network$dest_id == motif[i, j])])){
          binary_pos[k, j] = 1
        } 
        if (is.element("Pos", PPI_sig_network$relation[which(PPI_sig_network$dest_id == motif[i, k] & PPI_sig_network$src_id == motif[i, j])])){
          binary_pos[j, k] = 1
        }
      }
    }
  }
  index = 0
  decimal_phy = 0
  for (j in motif_node:1){
    for (k in motif_node:1){
      index = index + 1
      decimal_phy = decimal_phy + binary_phy[j, k] * 2 ^ (motif_node ^ 2 - index) 
    }
  }
  index = 0
  decimal_pos = 0
  for (j in motif_node:1){
    for (k in motif_node:1){
      index = index + 1
      decimal_pos = decimal_pos + binary_pos[j, k] * 2 ^ (motif_node ^ 2 - index) 
    }
  }
  motif$physical.path[i] = decimal_phy
  motif$positive.path[i] = decimal_pos
}

motif$subID = paste(paste(motif$negative.path, motif$physical.path, sep = "_"), motif$positive.path, sep = "_")




# Combine symmetric and loop motif
## If motif is symmetric or loop
motif_class = unique(motif$ID)
sym_motif_class = c()
for (i in 1:length(motif_class)){
  binary_ori = binary_matrix(motif_class[i])
  if (equivalent_matrix(binary_ori, binary_ori)[1] == TRUE){
    sym_motif_class = c(sym_motif_class, as.numeric(as.character(motif_class[i])))
  }
}

for (i in 1:length(sym_motif_class)){
  sub_motif_class = sort(unique(motif$subID[which(motif$ID == sym_motif_class[i])]))
  sub_motif_class_index = list()
  for (j in 1:length(sub_motif_class)){
    sub_motif_class_index[j] = 1
  }
  for (m in 1:(length(sub_motif_class) - 1)){
    if (sub_motif_class_index[m] == 1){
      for (n in (m + 1):length(sub_motif_class)){
        if (sub_motif_class_index[n] == 1){
          subID_1 = strsplit(sub_motif_class[m], split = "_")
          subID_2 = strsplit(sub_motif_class[n], split = "_")
          if (subID_1[[1]][2] == subID_2[[1]][2]){
            equivalent = equivalent_matrix((binary_matrix(sym_motif_class[i]) + binary_matrix(subID_1[[1]][1]) + binary_matrix(subID_1[[1]][3]) * 5), (binary_matrix(sym_motif_class[i]) + binary_matrix(subID_2[[1]][1]) + binary_matrix(subID_2[[1]][3]) * 5))
            if (equivalent[1] == TRUE){
              sub_motif_class_index[n] = 0
              temp = motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]), as.numeric(equivalent[2])]
              motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]), as.numeric(equivalent[2])] = motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[3])]
              motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]), as.numeric(equivalent[3])] = temp
              motif$subID[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n])] = sub_motif_class[m]
              if (length(equivalent) == 4){
                temp = motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[2])]
                motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[2])] = motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[3])]
                motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[3])] = temp
                temp = motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[2])]
                motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[2])] = motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[4])]
                motif[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n]),as.numeric(equivalent[4])] = temp
                motif$subID[which(motif$ID == sym_motif_class[i] & motif$subID == sub_motif_class[n])] = sub_motif_class[m]
              }
            }
          }
        }
      }     
    }
  }
  sub_motif_class = sub_motif_class[which(sub_motif_class_index == 1)]
}

motif_subclass = unique(paste(motif$ID, motif$subID, sep = "_"))

write.table(motif_subclass,"../data_out/motif_subclass.txt",sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE)
write.table(motif, file = "../data_out/motif")
write.table(motif, file = "../data_out/motif_store")
