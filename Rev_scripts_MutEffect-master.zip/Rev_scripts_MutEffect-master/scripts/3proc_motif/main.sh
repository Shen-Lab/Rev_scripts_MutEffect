#!/usr/bin/env bash 
Rscript proc_motif.r < filename.txt  
