# 20170310 by Haoran Chen
#edited by Suping Deng on 12/5/2018
library(AnnotationDbi)
library(org.Hs.eg.db)
library(R.utils)


binary_matrix = function(x){
  binary = matrix(0, nrow=motif_node, ncol=motif_node)
  str = strsplit(intToBin(as.integer(as.character(x))), split = "")
  index = length(str[[1]])
  for (j in 1:motif_node){
    for (k in 1:motif_node){
      if (index != 0){
        binary[j, k] = as.integer(str[[1]][index])
        index = index - 1
      } else{
        binary[j, k]= 0
      }
    }
  } 
  return(binary)
}


