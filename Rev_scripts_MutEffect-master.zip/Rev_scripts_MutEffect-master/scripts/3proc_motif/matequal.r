# 20170310 by Haoran Chen
#edited by Suping Deng on 12/5/2018

matequal = function(x, y){
  is.matrix(x) && is.matrix(y) && dim(x) == dim(y) && all(x == y)
}


