match_ratio = function(rule,true_label){
        if(true_label)==1 motif_sign=CGC_motif_sign else motif_sign=non_driver_motif_sign
	pre_label = apply(motif_sign,1,function(p){a = if(length(intersect(rule,p))==length(rule)) 1 else 0; a})
        ratio = sum(pre_label)/nrow(motif_sign)
        ratio 
}

