geneID_topRule = function(gene_id,gene_label,top_N){
	if(gene_label==1) gene_rule_motif = CGC_gene_rule_motif else gene_rule_motif = non_driver_gene_rule_motif
	geneIDs_top10Rulesets_motif = vector("list",top_N)
	for(i in 1:top_N){
        	index = which(gene_IDs==gene_id)
        	length_rule_motif = length(gene_rule_motif[[index]][[i]])
       	 	name_i_rule_motif = names(gene_rule_motif[[index]][[i]])
        	value_i_rule_motif = gene_rule_motif[[index]][[i]]
        	temp_geneids_rule = c()
        	for(j in 1:length_rule_motif){
                a_temp = c()
                for (k in 1:nrow(motif1)){
                        members_motif0 = motif1[k,1:3]
                        members_motif = gsub("^ +","",members_motif0)
                        if (length(which(gene_id==members_motif))>0 && motif_subclass[k]==name_i_rule_motif[j]) {
                                temp = c(motif1[k,],value_i_rule_motif[j])
                                a_temp = rbind(a_temp,temp)
                                colnames(a_temp)[ncol(a_temp)] = "motif_value_in_rule"
                                }
                        }
                temp_geneids_rule = rbind(temp_geneids_rule,a_temp)
                }
	       	geneIDs_top10Rulesets_motif[[i]] = temp_geneids_rule
	}
}
