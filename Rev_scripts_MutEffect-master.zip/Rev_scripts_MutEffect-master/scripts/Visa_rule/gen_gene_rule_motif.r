gen_gene_motif = function(true_label){
if(true_label==1) motif_sign = CGC_motif_sigh else motif_sign = non_driver_motif_sign
gene_rule_motif = list()

for(i in 1:nrow(motif_sign)){
        single_gene_rule_motif = list()
        for (j in 1:length(rank_rule_motif_sign)){
                motif_intersect_sign = intersect(motif_sign[i,],rank_rule_motif_sign[[j]])
                motif_intersect_value = sapply(motif_intersect_sign,function(p){v= if(grepl("=1",p)) 1 else 0;v})
                name_motif_intersect = sapply(motif_intersect_sign,function(p){nm0 = gsub("=1","",p);nm1 = gsub("=0","",nm0);nm1})
                names(motif_intersect_value) = name_motif_intersect
                single_gene_rule_motif[[j]] = motif_intersect_value
        }
        names(single_gene_rule_motif) = names(rank_rule_motif_sign)
        gene_rule_motif[[i]] = single_gene_rule_motif
}
gene_IDs = rownames(gene_motif)
names(gene_rule_motif) = gene_IDs
gene_rule_motif
}
