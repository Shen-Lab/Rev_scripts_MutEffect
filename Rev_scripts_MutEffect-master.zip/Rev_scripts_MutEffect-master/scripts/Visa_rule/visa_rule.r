library(stringr)
#read data
f = scan(file("stdin"),what=character(0),sep="\t")#f[1] is rule_extract.RData, f[2] is feature_label_motif.txt,f[3] is motif.
load(f[1])
gene_motif0 = read.table(f[2],sep="\t",head=TRUE,check.names=FALSE)
motif = read.table(f[3])
rule_all = rule_interpret$a # rule_a is rule sets
rule_b = rule_interpret$b # rule_b is rule-motif matrix
rule_class = rule_interpret$c # rule_c is class of rule sets

source("sel_rule.r")
#select rule sets with class==1
p_c1 = which(rule_c ==1)
rule_set = list()
for(i in 1:length(p_c1)){
	rule_set0 = rule_a[[i]][1]
	rule_set1 = unlist(strsplit(rule_set0,";"))
	rule_set2 = sapply(rule_set1,function(p){p0=gsub("^ ","",p);p1=gsub(" $","",p0);p1})
	names(rule_set2) = NULL
	rule_set[[i]] = rule_set2
	if (i ==1) rule_com = rule_set2 else rule_com = intersect(rule_com,rule_set2)
}
save(rule_set,file="../data_out/rule_set.RData")
writeLines(rule_com,"../data_out/rule_com.txt")

#rank the extracted rules in class 1 based on their average precision
## construct a binary rule_motif list
rule_motif = list()
for (i in 1:length(rule_set)){
	ri = rule_set[[i]]
	ri1 = rep(0, length(ri))
	name_ri1 = sapply(ri,function(p){nm0 = gsub(" > 0.5","",p);nm1 = gsub(" < 0.5","",nm0);nm1})
	names(name_ri1) = NULL
	for ( j in 1:length(ri)){
		if (grepl(">",ri[j])) ri1[j] = 1# also str_detect(ri[j],">")
	}
	names(ri1) = name_ri1
	rule_motif[[i]] = ri1
}
save(rule_motif,file="../data_out/rule_motif.RData")

#construct a rule_motif sign list
rule_motif_sign = sapply(rule_motif,function(p){paste(names(p),p,sep="=")})
save(rule_motif_sign,file="../data_out/rule_motif_sign.RData")


## construct a gene_motif_sign matrix

 
gene_motif = as.matrix(gene_motif0[,1:ncol(gene_motif)-1])
gene_motif = gene_motif[,1:ncol(gene_motif)-1]
motif_sign = matrix(,nrow=nrow(gene_motif),ncol=ncol(gene_motif))
for (i in 1:nrow(gene_motif)){
	motif_subclass = colnames(gene_motif)
	motif_sign[i,] = paste(motif_subclass,gene_motif[i,],sep="=")
}
rownames(motif_sign) = rownames(gene_motif)

#construct a positive motif_sign only containing driver genes, and a negative motif_sign only containing non_driver genes
label = gene_motif0$label
p_label0 = which(label==0)
p_label1 = which(label ==1)

##construct a CGC_motif sign matrix
CGC_motif_sign = motif_sign[p_label1,]
write.table(CGC_motif_sign,"../data_out/CGC_motif_sign.txt",quote=F,sep="\t")

#construct a negative motif_sign
non_driver_motif_sgign = motif_sign[p_label0,]
write.table(non_driver_motif_sign,"../data_out/non_driver_motif_sign.txt",quote=F,sep="\t")

## compute the match ratio of each rule within each class 
source("match_ratio.r")

#rank positive rule sets
matchRatio_rule1 = sapply(rule_motif_sign,function(r){match_ratio(r,1)})
names(matchRatio_rule1) = paste("rule",1:length(rule_motif),sep="")
rank_rule1 = sort(matchRatio_rule1,decreasing=T)
write.table(rank_rule1,"../data_out/rank_rule1.txt",sep="\t",quote=F)

#rank negative rule sets
matchRatio_rule0 = sapply(rule_motif_sign,function(r){match_ratio(r,0)})
names(matchRatio_rule0) = paste("rule",1:length(rule_motif),sep="")
rank_rule1 = sort(matchRatio_rule0,decreasing=T)
write.table(rank_rule0,"../data_out/rank_rule0.txt",sep="\t",quote=F)

#construct gene-rule-motif list
names(rule_motif_sign) = paste("rule",1:length(rule_motif),sep="")
#rank_rule_motif_sign = vector("list",length(rank_rule1))
rank_rule_motif_sign = list()
for(i in 1:length(rule_motif_sign)){
	rank_rule_name = names(rank_rule1)
	index = which(names(rule_motif_sign)==rank_rule_name[i])
	rank_rule_motif_sign[[i]]=rule_motif_sign[[index]]
}
names(rank_rule_motif_sign) = names(rank_rule1)
save(rank_rule_motif_sign,file="../rank_rule_motif.RData")


source("gen_gene_rule_motif_sign.r")

CGC_gene_rule_motif_sign = gen_gene_rule_motif_sign(1)
save(CGC_gene_rule_motif_sign,"../data_out/CGC_gene_rule_motif_sign.RData")

non_driver_gene_rule_motif_sign = gen_gene_rule_motif_sign(0)
save(non_driver_gene_rule_motif_sign,"../data_out/non_driver_gene_rule_motif_sign.RData")  


source("gen_gene_rule_motif.r")

CGC_gene_rule_motif = gen_gene_rule_motif(1)
save(CGC_gene_rule_motif,"../data_out/CGC_gene_rule_motif.RData")

non_driver_gene_rule_motif = gen_gene_rule_motif(0)
save(non_driver_gene_rule_motif,"../data_out/non_driver_gene_rule_motif.RData")  


motif_subclass = paste(motif$ID,motif$subID,sep="_")
motif1 = cbind(motif,motif_subclass)

#for a specific gene,select its top-N rule sets
source("geneID_topRule.r")

# for gene STAT3, ENTREZ ID: 6774, top-N rule sets
gene_id = 6774
top_N = 10
geneIDs_top10Rulesets_motif = geneID_topRule(gene_id=6774,top_N=10,gene_label=1)
save(geneIDs_top10Rulesets_motif,file="../data_out/geneIDs_top10Rulesets_motif_6774.RData")

#visualize a specific gene with the ith rule sets in top_N rule sets


