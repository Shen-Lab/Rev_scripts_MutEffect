library(org.Hs.eg.db)
k=keys(org.Hs.eg.db,keytype = "ENSEMBL")
list=select(org.Hs.eg.db,keys=k,columns = c("ENTREZID","SYMBOL"), keytype="ENSEMBL")
geneID=readLines("../data_out/unique_geneID.txt")
ID_list=list[match(geneID,list[,"ENTREZID"]),]
write.table(ID_list,"../data_out/genesymbolID.txt",quote=F,sep="\t",row.names=F)
top1_6774 = read.table("../data_out/top1_6774.txt",head=T,sep="\t")
top1_6774_1 = top1_6774
EID=as.vector(ID_list[,2])
gsymbol=as.vector(ID_list[,3])
for(i in 1:length(EID)){
	for(j in 1:3){
		p_temp = which(top1_6774_1[,j]==EID[i])
		top1_6774_1[p_temp,j] = gsymbol[i]
		top1_6774_1 = top1_6774_1
	}
}
write.table(top1_6774_1,"../data_out/top1rulese_6774_symbol.txt",sep="\t")
