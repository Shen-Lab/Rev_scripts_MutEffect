select_ruleset = function(all_ruleset,class){# all_ruleset is all of extracted rule sets by SGL,class is rule_class
	p_c = which(rule_c ==class)
	rule_set = list()
	for(i in 1:length(p_c1)){
        	rule_set0 = rule_a[[i]][1]
        	rule_set1 = unlist(strsplit(rule_set0,";"))
        	rule_set2 = sapply(rule_set1,function(p){p0=gsub("^ ","",p);p1=gsub(" $","",p0);p1})
        	names(rule_set2) = NULL
       	 	rule_set[[i]] = rule_set2
        	if (i ==1) rule_com = rule_set2 else rule_com = intersect(rule_com,rule_set2)
}
	return(rule_set)
}

