gen_gene_rule_motif_sign=function(true_label){
if(true_label==1) motif_sign = CGC_motif_sigh else motif_sign = non_driver_motif_sign 
gene_rule_motif_sign = list()

for(i in 1:nrow(motif_sign)){
        single_gene_rule_motif_sign = list()
        for (j in 1:length(rank_rule_motif_sign)){
                motif_intersect_sign = intersect(motif_sign[i,],rank_rule_motif_sign[[j]])
                single_gene_rule_motif_sign[[j]] = motif_intersect_sign
        }
        names(single_gene_rule_motif_sign) = names(rank_rule_motif_sign)
        gene_rule_motif_sign[[i]] = single_gene_rule_motif_sign
}
gene_IDs = rownames(gene_motif)
names(gene_rule_motif_sign) = gene_IDs
gene_rule_motif_sign
}
