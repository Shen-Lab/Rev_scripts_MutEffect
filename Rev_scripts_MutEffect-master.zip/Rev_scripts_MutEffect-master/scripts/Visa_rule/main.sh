#! /usr/bin/env bash
Rscript visa_rule.r < filename.txt
