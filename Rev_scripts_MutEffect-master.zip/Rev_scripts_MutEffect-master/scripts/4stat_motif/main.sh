#!/usr/bin/env bash

Rscript stat_motif.r < filename.txt 
