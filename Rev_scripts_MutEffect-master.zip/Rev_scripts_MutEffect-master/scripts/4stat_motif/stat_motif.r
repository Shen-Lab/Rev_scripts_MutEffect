#! /usr/bin/env Rscript

#edited by Suping Deng on 11/28/2018

library(AnnotationDbi)
library(org.Hs.eg.db)
library(R.utils)
library(gplots)

#read data
f<-scan(file("stdin"),what=character(0),sep="\t")#f[1]is PPI_sig_network_no_selfloop.txt; f[2] is Census.csvk;f[3] is motif.


PPI_sig_network =read.table(f[1],sep="\t",head=TRUE)
CGC = read.csv(f[2], fill = TRUE, header = T)
motif =read.table(f[3])

#get intersection gene ID
names_CGC = as.character(CGC[,1])
names_CGC_ID = c()
for (i in 1:length(names_CGC)){
  name_temp_ID = mget(as.character(names_CGC[i]), revmap(org.Hs.egSYMBOL), ifnotfound = NA)[[1]][1]
  names_CGC_ID = c(names_CGC_ID, name_temp_ID)
}
names_CGC_ID = names_CGC_ID[-which(is.na(names_CGC_ID) == TRUE)]


names_motif_ID = unique(c(motif[, 1], motif[, 2], motif[, 3]))
names_intersect_ID = intersect(names_motif_ID, names_CGC_ID)

#get motifs containing driver genes
motif_subclass=unique(paste(motif$ID,motif$subID, sep ="_"))




# Generate random mutations
network_gene_id = unique(c(PPI_sig_network[,1], PPI_sig_network[,2]))
CGC_stat_dist.random = matrix(0, ncol = length(motif_subclass), nrow = 1000)
colnames(CGC_stat_dist.random) = motif_subclass
set.seed(123) 
for (n in 1:1000){	
	CGC.mutation.missense.matched.random = network_gene_id[sample(1:length(network_gene_id), length(names_intersect_ID), replace = T)] 
	CGC_gene_id.random = unique(CGC.mutation.missense.matched.random)
#   # Get gene-motif table
  	CGC_gene_matrix.random = matrix(0, ncol = length(motif_subclass), nrow = length(CGC_gene_id.random))
  	colnames(CGC_gene_matrix.random) = motif_subclass
  	rownames(CGC_gene_matrix.random) = CGC_gene_id.random
  for (i in 1:length(CGC_gene_id.random)){
    	id_temp = which(motif[, 1] == rownames(CGC_gene_matrix.random)[i] | motif[, 2] == rownames(CGC_gene_matrix.random)[i] | motif[, 3] == rownames(CGC_gene_matrix.random)[i])
    	for (j in 1:length(id_temp)){
      		col_temp = which(colnames(CGC_gene_matrix.random) == paste(motif$ID[id_temp[j]], motif$subID[id_temp[j]], sep = "_"))
     		 CGC_gene_matrix.random[i, col_temp] = CGC_gene_matrix.random[i, col_temp] + 1
    	}
  }
  # Get mutation distribution
  CGC_matrix.random = CGC_gene_matrix.random
  for (i in 1:length(motif_subclass)){
    CGC_stat_dist.random[n, i] = sum(CGC_matrix.random[, i])
  }
}
write.table(CGC_stat_dist.random, file = "../data_out/random/CGC_stat_dist.random.txt",sep= "\t", quote = F)


# Generate true distribution
CGC_gene_id.true =names_intersect_ID 
# Get CGCgene-motif table
CGC_gene_matrix.true = matrix(0, ncol = length(motif_subclass), nrow = length(CGC_gene_id.true))
colnames(CGC_gene_matrix.true) = motif_subclass
rownames(CGC_gene_matrix.true) = CGC_gene_id.true
for (i in 1:length(CGC_gene_id.true)){
  id_temp = which(motif[, 1] == rownames(CGC_gene_matrix.true)[i]| motif[, 2] == rownames(CGC_gene_matrix.true)[i] | motif[, 3] == rownames(CGC_gene_matrix.true)[i])
  for (j in 1:length(id_temp)){
    col_temp = which(colnames(CGC_gene_matrix.true) == paste(motif$ID[id_temp[j]], motif$subID[id_temp[j]], sep = "_"))
    CGC_gene_matrix.true[i, col_temp] = CGC_gene_matrix.true[i, col_temp] + 1
  }
}
write.table(CGC_gene_matrix.true,"CGC_gene_matrix.true.txt",quote=F,sep="\t")

# Get unlabelgene-motif table
names_unlabel_ID = setdiff(names_motif_ID, names_CGC_ID)
unlabel_gene_id.true =names_intersect_ID
unlabel_gene_matrix.true = matrix(0, ncol = length(motif_subclass), nrow = length(unlabel_gene_id.true))
colnames(unlabel_gene_matrix.true) = motif_subclass
rownames(unlabel_gene_matrix.true) = unlabel_gene_id.true
for (i in 1:length(unlabel_gene_id.true)){
  id_temp = which(motif[, 1] == rownames(unlabel_gene_matrix.true)[i]| motif[, 2] == rownames(unlabel_gene_matrix.true)[i] | motif[, 3] == rownames(unlabel_gene_matrix.true)[i])
  for (j in 1:length(id_temp)){
    col_temp = which(colnames(unlabel_gene_matrix.true) == paste(motif$ID[id_temp[j]], motif$subID[id_temp[j]], sep = "_"))
    unlabel_gene_matrix.true[i, col_temp] = unlabel_gene_matrix.true[i, col_temp] + 1
  }
}
write.table(unlabel_gene_matrix.true,"unlabel_gene_matrix.true.txt",quote=F,sep="\t")

# Get mutation distribution
CGC_matrix.true = CGC_gene_matrix.true
CGC_stat_dist.true = rep(0, length(motif_subclass))
names(CGC_stat_dist.true) = motif_subclass
for (i in 1:length(CGC_stat_dist.true)){
  CGC_stat_dist.true[i] = sum(CGC_matrix.true[, i])
}

write.table(CGC_stat_dist.true, file = "../data_out/random/CGC_stat_dist.true.txt",sep= "\t", quote = F)

# Check mutation hotspot
motif_sample_stat_dist = rep(0, length(motif_subclass))
names(motif_sample_stat_dist) = motif_subclass

for (i in 1:ncol(CGC_stat_dist.random)){
  if ((length(which(CGC_stat_dist.random[, i] >= CGC_stat_dist.true[i])) / dim(CGC_stat_dist.random)[1]) <= 0.001){
    motif_sample_stat_dist[i] = "Pos"
  } else if ((length(which(CGC_stat_dist.random[, i] < CGC_stat_dist.true[i])) / dim(CGC_stat_dist.random)[1]) <= 0.001){
    motif_sample_stat_dist[i] = "Neg"
  } else {
    motif_sample_stat_dist[i] = "None"
  }
}

filename = paste("../data_out/", "hot_motif_stat.txt", sep = "")
write.table(motif_sample_stat_dist, file = filename, sep="\t",quote = F)
#write.table(motif_sample_stat_dist,stdout,sep="\t",quote=F)
