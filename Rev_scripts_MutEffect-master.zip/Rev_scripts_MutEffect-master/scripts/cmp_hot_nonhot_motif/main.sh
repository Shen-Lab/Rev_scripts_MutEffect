#! /usr/bin/env bash
Rscript cmp_hot_nonhot_motif.r < filename.txt
