# read data
f = scan(file("stdin"),what=character(0),sep="\t")#f[1] is overlap_hotmotif.txt,f[2] is CGC_gene_matrix.true.txt
overlap_hotmotif = readLines(f[1])
CGC_gene_matrix.true=read.table(f[2],sep="\t",head=T,check.names=FALSE)
driver_gene_hotmotif=CGC_gene_matrix.true[,overlap_hotmotif]
write.table(driver_gene_hotmotif,"../data_out/driver_gene_hotmotif.txt",quote=F,sep="\t")
count_driver_gene_hotmotif=apply(driver_gene_hotmotif,2,sum)
write.table(count_driver_gene_hotmotif,"../data_out/count_driver_gene_hotmotif.txt",quote=F,sep="\t")
nonhotmotif=setdiff(colnames(CGC_gene_matrix.true),overlap_hotmotif)
driver_gene_nonhotmotif= CGC_gene_matrix.true[,nonhotmotif]
write.table(driver_gene_nonhotmotif,"../data_out/driver_gene_nonhotmotif.txt",quote=F,sep="\t")
count_driver_gene_nonhotmotif=apply(driver_gene_nonhotmotif,2,sum)
write.table(count_driver_gene_nonhotmotif,"../data_out/count_driver_gene_nonhotmotif.txt",quote=F,sep="\t")
cmp=t.test(count_driver_gene_hotmotif,count_driver_gene_nonhotmotif)
saveRDS(cmp,"../data_out/cmp_hot_nonhotmotif.rds")



